<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

## Project : Book Review

## Kelompok 2

Nama Kelompok :

    Backend :
    - Anisah Fauziyah
        Pengerjaan : Crud Category, Author, Reviewer, dan Otp_code, Regenerateotp, ChangePassword
    - Prayoga Erlangga Putra
        Pengerjaan : Crud Register, Login, Book, Review, dan Dokumentasi API

    Frontend :
    - Syamsu Rijal
    - Fandi

Dokumentasi API : https://documenter.getpostman.com/view/19689090/UVyyrs7h
